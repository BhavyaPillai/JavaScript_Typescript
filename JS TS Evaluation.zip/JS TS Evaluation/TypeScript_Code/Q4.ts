abstract class HospitalStaff{
    abstract getSalary():number;
    abstract getRole():string;
}

class Surgeon extends HospitalStaff {
    name:string;
    role:string;
    salary:number;
    
    constructor(name:string, role:string, salary:number){
        super();
        this.salary = salary;
        this.name = name;
        this.role = role;
    }
    getSalary(): number {
        return this.salary;
    }
    getRole(): string {
        return this.role;
    }

    
}

class Receptionist extends HospitalStaff {
    name:string;
    role:string;
    salary:number;

    constructor(name:string, role:string, salary:number){
        super();
        this.salary = salary;
        this.name = name;
        this.role = role;
    }

    getSalary(): number {
        return this.salary;
    }
    getRole(): string {
        return this.role;
    }
    
}

const ob1 = new Surgeon("Dr. Smith", "Cardiothoracic Surgeon", 150000);
const ob2 = new Receptionist("Jane Doe", "Front Desk Receptionist", 40000);

console.log("Surgeon Salary: ", ob1.getSalary());
console.log("Surgeon Role: ", ob1.getRole());
console.log("Receptionist Salary: ", ob2.getSalary());
console.log("Receptionist Role: ", ob2.getRole());
