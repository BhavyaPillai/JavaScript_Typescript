class Ward{
    wardName:string
    capacity:number
    inChargeDoctor:string

    constructor(wname:string, cap:number, inCharge:string) {
        this.wardName = wname;
        this.capacity = cap;
        this.inChargeDoctor = inCharge;
    }
    displayInfo(): void {
        console.log("WardName :", this.wardName);
        console.log("Capacity :", this.capacity);
        console.log("inCharge :", this.inChargeDoctor);
    }
}

const ob = new Ward("A",100, "HP");
const ob1 = new Ward("B",100, "HP");

ob.displayInfo();
ob1.displayInfo();