import { varSend, func, Patient } from "./Q2";

console.log(varSend); 
console.log(func("World")); 
const obj = new Patient();
console.log(obj.greet()); 

// To install TypeScript and run TypeScript code:
// npm install -g typescript
// tsc Q2.ts Q2Import.ts
// run Q2Import.js