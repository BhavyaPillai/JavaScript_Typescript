var Ward = /** @class */ (function () {
    function Ward(wname, cap, inCharge) {
        this.wardName = wname;
        this.capacity = cap;
        this.inChargeDoctor = inCharge;
    }
    Ward.prototype.displayInfo = function () {
        console.log("WardName :", this.wardName);
        console.log("Capacity :", this.capacity);
        console.log("inCharge :", this.inChargeDoctor);
    };
    return Ward;
}());
var ob = new Ward("A", 100, "HP");
var ob1 = new Ward("B", 100, "HP");
ob.displayInfo();
ob1.displayInfo();
