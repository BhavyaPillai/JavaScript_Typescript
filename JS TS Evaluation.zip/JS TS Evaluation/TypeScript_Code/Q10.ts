function getPatientInfo<T>(data: T): T {
    return data;
}

console.log(getPatientInfo<string>("Harsh"));
console.log(getPatientInfo<number>(100));