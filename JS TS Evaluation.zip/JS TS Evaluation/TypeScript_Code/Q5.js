var Receptionist = /** @class */ (function () {
    function Receptionist(name) {
        this.appointmentList = [];
        this.name = name;
    }
    Receptionist.prototype.scheduleAppointment = function (customer) {
        this.appointmentList.push(customer);
        console.log("Appointment for " + customer + "is queued.");
    };
    Receptionist.prototype.getAllAppointment = function () {
        console.log("Receptionist Name :" + this.name);
        console.log("All Appointments: ", this.appointmentList);
    };
    return Receptionist;
}());
var ob = new Receptionist("JOhn");
ob.scheduleAppointment("Raj");
ob.scheduleAppointment("A");
ob.scheduleAppointment("B");
ob.scheduleAppointment("C");
ob.getAllAppointment();
