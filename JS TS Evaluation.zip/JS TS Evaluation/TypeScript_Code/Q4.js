var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var HospitalStaff = /** @class */ (function () {
    function HospitalStaff() {
    }
    return HospitalStaff;
}());
var Surgeon = /** @class */ (function (_super) {
    __extends(Surgeon, _super);
    function Surgeon(name, role, salary) {
        var _this = _super.call(this) || this;
        _this.salary = salary;
        _this.name = name;
        _this.role = role;
        return _this;
    }
    Surgeon.prototype.getSalary = function () {
        return this.salary;
    };
    Surgeon.prototype.getRole = function () {
        return this.role;
    };
    return Surgeon;
}(HospitalStaff));
var Receptionist = /** @class */ (function (_super) {
    __extends(Receptionist, _super);
    function Receptionist(name, role, salary) {
        var _this = _super.call(this) || this;
        _this.salary = salary;
        _this.name = name;
        _this.role = role;
        return _this;
    }
    Receptionist.prototype.getSalary = function () {
        return this.salary;
    };
    Receptionist.prototype.getRole = function () {
        return this.role;
    };
    return Receptionist;
}(HospitalStaff));
var ob1 = new Surgeon("Dr. Smith", "Cardiothoracic Surgeon", 150000);
var ob2 = new Receptionist("Jane Doe", "Front Desk Receptionist", 40000);
console.log("Surgeon Salary: ", ob1.getSalary());
console.log("Surgeon Role: ", ob1.getRole());
console.log("Receptionist Salary: ", ob2.getSalary());
console.log("Receptionist Role: ", ob2.getRole());
