export const varSend = 42;

export function func(name: string): string {
	return `Hello, ${name}!`;
}

export class Patient {
	greet() {
		return "Hello from Patient!";
	}
}
