"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Q2_1 = require("./Q2");
console.log(Q2_1.varSend);
console.log((0, Q2_1.func)("World"));
var obj = new Q2_1.Patient();
console.log(obj.greet());
// To install TypeScript and run TypeScript code:
// npm install -g typescript
// tsc Q2.ts Q2Import.ts
// run Q2Import.js
