"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Patient = exports.varSend = void 0;
exports.func = func;
exports.varSend = 42;
function func(name) {
    return "Hello, ".concat(name, "!");
}
var Patient = /** @class */ (function () {
    function Patient() {
    }
    Patient.prototype.greet = function () {
        return "Hello from Patient!";
    };
    return Patient;
}());
exports.Patient = Patient;
