function getPatientInfo(data) {
    return data;
}
console.log(getPatientInfo("Harsh"));
console.log(getPatientInfo(100));
