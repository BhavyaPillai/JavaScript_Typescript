interface AppointmentManagement{
    scheduleAppointment(customer:string): void;
}

class Receptionist implements AppointmentManagement {
    name:string;
    appointmentList:string[] = [];
    
    constructor(name:string) {
        this.name = name;
    }
    
    scheduleAppointment(customer:string): void {
        this.appointmentList.push(customer);
        console.log("Appointment for "+customer+ "is queued.");
    }

    getAllAppointment():void {
        console.log("Receptionist Name :"+this.name);
        console.log("All Appointments: ", this.appointmentList);
    }
}

const ob = new Receptionist("JOhn");
ob.scheduleAppointment("Raj");
ob.scheduleAppointment("A");
ob.scheduleAppointment("B");
ob.scheduleAppointment("C");

ob.getAllAppointment();