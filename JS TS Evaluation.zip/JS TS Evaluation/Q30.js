function totalDeff(cost) {
    console.log("Totol Costtt "+cost);
}
function totalres(...rest) {
    console.log("Totol Costtt "+rest);
}

totalDeff(100);
totalres(1000)